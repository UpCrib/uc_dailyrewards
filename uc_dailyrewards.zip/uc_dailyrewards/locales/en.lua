Locales['en'] = {

  ['server_prefix']              = "UPCRIB RP",
  ['rewards_claimed_for_day']    = "Rewards claimed for day ",
  
}