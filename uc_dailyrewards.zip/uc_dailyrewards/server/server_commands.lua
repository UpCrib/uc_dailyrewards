-- Default Command to open the daily rewards.
RegisterCommand('dailyrewards',function(source)
    TriggerClientEvent('uc_dailyrewards:openDailyRewards',source)
end)
