Config              = {}

Config.Locale       = "en"

Config.UseKeyToOpen = false
Config.KeyToOpen    = 0

-- Checks if player received reward / not and day changed to update its data.
-- Default is every 10 minutes.
Config.ThreadRepeat = 10

-- If Config.MythicNotifyMessage is set to false, ESX Messages will be sent than mythic_notify.
Config.MythicNotifyMessage = false

Config.RewardPacks    = {
    ['clips'] = {
        rewards = {
            ['1'] = {name = "ammo-45",  type = "item", amount = 50},
            ['2'] = {name = "ammo-9",   type = "item", amount = 25},
            ['3'] = {name = "ammo-shotgun",     type = "item", amount = 15},
            ['4'] = {name = "ammo-rifle",     type = "item", amount = 40},
        },
    },
    ['moneyrewards'] = {
        rewards = {
            ['1'] = {name = "",  type = "money", amount = 500},
            ['2'] = {name = "",  type = "black_money", amount = 500},
            ['3'] = {name = "",  type = "bank", amount = 2500},
        },
    },

   
}

-- Player-specific progression (starting from the day they first join).
-- Rewards now based on the number of days the player has logged in, tracked per player.
-- Max days for getting daily rewards are 28 (4 Weeks).

-- For testing, you can do it manually from dailyrewards sql table, set day and received to 0

-- Default types: [item, weapon, money, black_money, bank].
-- If you want to give multiple items / money or anything in 1 daily reward, you can use Config.RewardPacks name,
-- for example, than using default types, you would use as type the custom pack, "clips" or anything else that you've made.
Config.DailyRewards = {
    ['WEEK_1'] = {
        {
            day = 1,
            dayReward = {
                type = 'moneyrewards',
                reward = 'CASH',
                amount = 1,
                title = 'MONEY REWARDS',
                description = '$500 CASH, $500 BLACK MONEY & $2500 BANK ACCOUNT',
                image = 'img/items/coins_rewardbox.png'
            },
        },
        {
            day = 2,
            dayReward = {
                type = 'clips',
                reward = 'clips',
                amount = 1,
                title = 'AMMO',
                description = 'PISTOL, AR, SG & SMG AMMO',
                image = 'img/items/ammo_rewardbox.png'
            },
        },
    
        {
            day = 3,
            dayReward = {
                type = 'item',
                reward = 'cbo',
                amount = 5,
                title = 'CBO Burger',
                description = '5X CBO BURGERS',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
    
        {
            day = 4,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_MICROSMG',
                amount = 1,
                title = 'UZI',
                description = 'New additon to your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },
    
        {
            day = 5,
            dayReward = {
                type = 'item',
                reward = 'medikit',
                amount = 5,
                title = 'MEDICAL',
                description = '5X MEDKITS',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
        {
            day = 6,
            dayReward = {
                type = 'item',
                reward = 'uptoken',
                amount = 25,
                title = 'UPTOKEN',
                description = '25X UPTOKENS',
                image = 'img/items/uptoken_rewardbox.png'
            },
        },
    
        {
            day = 7,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_COMPACTRIFLE',
                amount = 1,
                title = 'COMPACT RIFLE',
                description = 'New additon to your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },
    },

    ['WEEK_2'] = {
        {
            day = 8,
            dayReward = {
                type = 'money',
                reward = 'CASH',
                amount = 5000,
                title = 'CASH',
                description = '$5000 CASH',
                image = 'img/items/coins_rewardbox.png'
            },
        },

        {
            day = 9,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_COMBATPDW',
                amount = 1,
                title = 'UMP-45',
                description = 'New additon to your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },

        {
            day = 10,
            dayReward = {
                type = 'item',
                reward = 'boombox',
                amount = 1,
                title = 'BOOMBOX',
                description = '1X BOOMBOX',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
        {
            day = 11,
            dayReward = {
                type = 'item',
                reward = 'medikit',
                amount = 5,
                title = 'MEDICAL',
                description = '5x MEDICAL SUPPLEMENTS',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
        {
            day = 12,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_PUMPSHOTGUN',
                amount = 1,
                title = 'PUMP SHOTGUN',
                description = 'New additon to your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },
        {
            day = 13,
            dayReward = {
                type = 'clips',
                reward = 'clips',
                amount = 1,
                title = 'AMMO',
                description = 'PISTOL, AR, SG & SMG AMMO',
                image = 'img/items/ammo_rewardbox.png'
            },
        },
        {
            day = 14,
            dayReward = {
                type = 'item',
                reward = 'uptoken',
                amount = 35,
                title = 'UPTOKEN',
                description = '35X UPTOKENS',
                image = 'img/items/uptoken_rewardbox.png'
            },
        },
    },

    ['WEEK_3'] = {
        {
            day = 15,
            dayReward = {
                type = 'moneyrewards',
                reward = 'CASH',
                amount = 2,
                title = 'MONEY REWARDS',
                description = '2X $500 CASH, $500 BLACK MONEY & $2500 BANK ACCOUNT',
                image = 'img/items/coins_rewardbox.png'
            },
        },
        {
            day = 16,
            dayReward = {
                type = 'clips',
                reward = 'clips',
                amount = 2,
                title = 'AMMO',
                description = '2X PISTOL, AR, SG & SMG AMMO',
                image = 'img/items/ammo_rewardbox.png'
            },
        },
    
        {
            day = 17,
            dayReward = {
                type = 'item',
                reward = 'taco',
                amount = 10,
                title = 'TACOS',
                description = '10X TACOS',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
    
        {
            day = 18,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_KNIFE',
                amount = 1,
                title = 'KNIFE',
                description = 'New additon to your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },
    
        {
            day = 19,
            dayReward = {
                type = 'item',
                reward = 'repairkit',
                amount = 5,
                title = 'REPAIR KIT',
                description = '5X REPAIR KITS',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
        {
            day = 20,
            dayReward = {
                type = 'item',
                reward = 'uptoken',
                amount = 30,
                title = 'UPTOKEN',
                description = '30X UPTOKENS',
                image = 'img/items/uptoken_rewardbox.png'
            },
        },
    
        {
            day = 21,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_REVOLVER',
                amount = 1,
                title = 'REVOLVER',
                description = 'New additon to your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },
    },

    ['WEEK_4'] = {
        {
            day = 22,
            dayReward = {
                type = 'money',
                reward = 'CASH',
                amount = 15000,
                title = 'CASH',
                description = '$15000 CASH',
                image = 'img/items/coins_rewardbox.png'
            },
        },

        {
            day = 23,
            dayReward = {
                type = 'item',
                reward = 'uptoken',
                amount = 50,
                title = 'UPTOKEN',
                description = '50X UPTOKENS',
                image = 'img/items/uptoken_rewardbox.png'
            },
        },

        {
            day = 24,
            dayReward = {
                type = 'item',
                reward = 'wayne_laptop',
                amount = 1,
                title = 'TUNER LAPTOP',
                description = '1x TUNER LAPTOP',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
        {
            day = 25,
            dayReward = {
                type = 'item',
                reward = 'raine',
                amount = 25,
                title = 'WATER',
                description = '25X WATER',
                image = 'img/items/items_rewardbox.png'
            },
        },
    
        {
            day = 26,
            dayReward = {
                type = 'weapon',
                reward = 'WEAPON_WFREDTIGER',
                amount = 1,
                title = 'RED TIGER',
                description = 'New donor weapon for your arsenal.',
                image = 'img/items/weapons_rewardbox.png'
            },
        },
        {
            day = 27,
            dayReward = {
                type = 'clips',
                reward = 'clips',
                amount = 3,
                title = 'AMMO',
                description = '3X PISTOL, AR, SG & SMG AMMO',
                image = 'img/items/ammo_rewardbox.png'
            },
        },
        {
            day = 28,
            dayReward = {
                type = 'item',
                reward = 'uptoken',
                amount = 75,
                title = 'UPTOKEN',
                description = '75X UPTOKENS',
                image = 'img/items/uptoken_rewardbox.png'
            },
        },
    },
}
-- Logic for player-specific daily rewards progression
Config.CalculatePlayerDay = function(playerJoinDate)
    local currentTime = os.time()
    local daysPassed = math.floor((currentTime - playerJoinDate) / (24 * 60 * 60))
    return daysPassed + 1 -- Add 1 so that the first day is Day 1
end